import React from 'react';
import { Navbar } from './components/Navbar';
import { Editor } from './components/editor/Editor';
import { Preview } from './components/preview/Preview';
import { useStore } from './store/useStore';
import { dictionaries } from './i18n/dictionaries';
import { Edit3, Eye } from 'lucide-react';
import { cn } from './lib/utils';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const { mobileViewMode, setMobileViewMode, language } = useStore();
  const dict = dictionaries[language];

  return (
    <div className="flex flex-col h-screen bg-[#f5f5f4] font-sans antialiased overflow-hidden selection:bg-black selection:text-white">
      <Navbar />
      
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        {/* Editor Pane */}
        <AnimatePresence mode="wait">
          {(mobileViewMode === 'edit' || window.innerWidth >= 1024) && (
            <motion.div 
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              transition={{ duration: 0.3, ease: 'easeOut' }}
              className={cn(
                "w-full lg:w-[420px] xl:w-[460px] h-full bg-white border-r border-stone-200 flex flex-col shrink-0 z-20 shadow-xl lg:shadow-none",
                mobileViewMode === 'preview' ? "hidden lg:flex" : "flex"
              )}
            >
              <Editor />
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Preview Pane */}
        <div className={cn(
          "flex-1 h-full bg-stone-100 overflow-hidden relative transition-all duration-500 ease-in-out",
          mobileViewMode === 'edit' ? "hidden lg:block" : "block"
        )}>
          {/* Subtle background texture for premium feel */}
          <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none" />
          <Preview />
        </div>

        {/* Mobile View Switcher (Floating Bottom Bar) */}
        <div className="lg:hidden fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] w-max">
          <motion.div 
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="flex bg-black/80 backdrop-blur-xl rounded-full p-2 shadow-[0_20px_50px_rgba(0,0,0,0.3)] border border-white/10"
          >
            <button
              onClick={() => setMobileViewMode('edit')}
              className={cn(
                "flex items-center gap-2 px-6 py-3 rounded-full transition-all relative overflow-hidden",
                mobileViewMode === 'edit' ? "text-black" : "text-stone-400"
              )}
            >
              {mobileViewMode === 'edit' && (
                <motion.div layoutId="mobile-pill" className="absolute inset-0 bg-white" transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }} />
              )}
              <span className="relative flex items-center gap-2">
                <Edit3 className="w-4 h-4" />
                <span className="text-[10px] font-black uppercase tracking-widest">{dict.app.editor}</span>
              </span>
            </button>
            <button
              onClick={() => setMobileViewMode('preview')}
              className={cn(
                "flex items-center gap-2 px-6 py-3 rounded-full transition-all relative overflow-hidden",
                mobileViewMode === 'preview' ? "text-black" : "text-stone-400"
              )}
            >
              {mobileViewMode === 'preview' && (
                <motion.div layoutId="mobile-pill" className="absolute inset-0 bg-white" transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }} />
              )}
              <span className="relative flex items-center gap-2">
                <Eye className="w-4 h-4" />
                <span className="text-[10px] font-black uppercase tracking-widest">{dict.app.preview}</span>
              </span>
            </button>
          </motion.div>
        </div>
      </main>
    </div>
  );
}

