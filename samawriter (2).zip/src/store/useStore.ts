import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Language, PortfolioData, ThemeType } from '../types';

export type TabType = 'content' | 'templates' | 'settings' | 'profile';
export type MobileViewMode = 'edit' | 'preview';

interface AppState {
  language: Language;
  activeTab: TabType;
  mobileViewMode: MobileViewMode;
  data: PortfolioData;
  exportCount: number;
  isPro: boolean;
  setLanguage: (lang: Language) => void;
  setActiveTab: (tab: TabType) => void;
  setMobileViewMode: (mode: MobileViewMode) => void;
  incrementExportCount: () => void;
  setProStatus: (status: boolean) => void;
  updatePersonalInfo: (info: Partial<PortfolioData['personalInfo']>) => void;
  updateData: (data: Partial<PortfolioData>) => void;
  setTheme: (theme: ThemeType) => void;
}

const initialData: PortfolioData = {
  personalInfo: {
    fullName: 'Samariddin Rajabov',
    title: 'Senior Software Architect',
    email: 'samariddin@sama.ai',
    phone: '+998 90 123 45 67',
    location: 'Tashkent, Uzbekistan',
    about: 'Visionary technologist and lead architect at SAMA. Passionate about building global AI-driven products from zero budget to market leaders. Expert in React, Node.js, and scaling high-performance engineering teams.',
  },
  experiences: [
    {
      id: '1',
      company: 'SAMA AI',
      position: 'Chief Technology Officer',
      startDate: '2023-01-01',
      endDate: '',
      current: true,
      description: 'Leading the technical vision and engineering roadmap for SAMA. Automating movie localization workflows using cutting-edge STT/TTS models.',
    }
  ],
  projects: [
    {
      id: 'p1',
      title: 'Global Dubbing Hub',
      description: 'An automated pipeline for high-fidelity voice cloning in 50+ languages.',
      link: 'https://github.com/sama-ai/dubbing',
      technologies: ['React', 'Python', 'FFmpeg', 'WebCode'],
    }
  ],
  skills: [
    { id: 's1', name: 'React Architecture', level: 95 },
    { id: 's2', name: 'Full-stack Performance', level: 90 },
    { id: 's3', name: 'AI/ML Engineering', level: 85 },
  ],
  socialLinks: [
    { id: 'l1', platform: 'GitHub', url: 'https://github.com/sama-ai' },
    { id: 'l2', platform: 'LinkedIn', url: 'https://linkedin.com/' },
  ],
  theme: 'minimalist',
};

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      language: 'en',
      activeTab: 'content',
      mobileViewMode: 'edit',
      data: initialData,
      exportCount: 0,
      isPro: false,
      setLanguage: (language) => set({ language }),
      setActiveTab: (activeTab) => set({ activeTab }),
      setMobileViewMode: (mobileViewMode) => set({ mobileViewMode }),
      incrementExportCount: () => set((state) => ({ exportCount: state.exportCount + 1 })),
      setProStatus: (isPro) => set({ isPro }),
      updatePersonalInfo: (info) =>
        set((state) => ({
          data: {
            ...state.data,
            personalInfo: { ...state.data.personalInfo, ...info },
          },
        })),
      updateData: (newData) =>
        set((state) => ({
          data: { ...state.data, ...newData },
        })),
      setTheme: (theme) =>
        set((state) => ({
          data: { ...state.data, theme },
        })),
    }),
    {
      name: 'portfolio-storage',
    }
  )
);
