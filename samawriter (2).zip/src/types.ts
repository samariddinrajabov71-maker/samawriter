export type Language = 'en' | 'uz' | 'ru';

export interface PersonalInfo {
  fullName: string;
  title: string;
  email: string;
  phone: string;
  location: string;
  about: string;
  avatarUrl?: string;
}

export interface Experience {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  current: boolean;
  description: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  link: string;
  technologies: string[];
}

export interface Skill {
  id: string;
  name: string;
  level: number; // 0-100
}

export interface SocialLink {
  id: string;
  platform: string;
  url: string;
}

export type ThemeType = 'minimalist' | 'developer' | 'creative';

export interface PortfolioData {
  personalInfo: PersonalInfo;
  experiences: Experience[];
  projects: Project[];
  skills: Skill[];
  socialLinks: SocialLink[];
  theme: ThemeType;
}
