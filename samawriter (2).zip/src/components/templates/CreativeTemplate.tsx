import React from 'react';
import { PortfolioData } from '../../types';

export const CreativeTemplate: React.FC<{ data: PortfolioData }> = ({ data }) => {
  const { personalInfo: info, experiences, projects, skills, socialLinks } = data;

  return (
    <div className="min-h-full bg-[#fdfaf5] text-[#2d2d2d] p-16 font-serif">
      <div className="max-w-4xl mx-auto shadow-[20px_20px_0px_#ff6b6b] border-4 border-[#2d2d2d] bg-white p-12">
        <header className="mb-16 relative">
          <div className="absolute -top-20 -right-8 w-40 h-40 bg-[#ff6b6b] rounded-full mix-blend-multiply opacity-20" />
          <div className="absolute top-0 -left-12 w-24 h-24 bg-[#4ecdc4] rounded-full mix-blend-multiply opacity-20" />
          
          <h1 className="text-7xl font-black mb-4 uppercase tracking-tighter leading-none relative z-10 antialiased">
            {info.fullName || 'Creative Profile'}
          </h1>
          <p className="text-2xl font-bold text-[#ff6b6b] py-2 px-4 border-2 border-[#2d2d2d] inline-block mb-8 bg-white skew-x-[-4deg] shadow-[4px_4px_0px_#2d2d2d]">
            {info.title || 'Multidisciplinary Designer'}
          </p>
          
          <div className="flex flex-wrap gap-8 text-sm font-bold uppercase tracking-widest text-slate-400">
            {info.email && <span className="hover:text-[#4ecdc4] transition-colors cursor-pointer">{info.email}</span>}
            {info.location && <span>{info.location}</span>}
          </div>
        </header>

        <main className="space-y-20">
          <section className="grid grid-cols-12 gap-8">
            <div className="col-span-4 self-center">
              <h2 className="text-4xl font-black uppercase rotate-[-90deg] origin-center -translate-x-4 border-b-8 border-[#ffe66d]">About</h2>
            </div>
            <div className="col-span-8">
              <p className="text-xl leading-relaxed italic opacity-80 border-l-4 border-[#2d2d2d] pl-8">
                {info.about}
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-3xl font-black uppercase mb-10 inline-block bg-[#ffe66d] px-6 py-2 shadow-[8px_8px_0px_#2d2d2d]">Milestones</h2>
            <div className="space-y-16">
              {experiences.map((exp) => (
                <div key={exp.id} className="relative pl-12 group">
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-[#2d2d2d] opacity-20 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute left-[-6px] top-2 w-4 h-4 bg-[#ff6b6b] border-2 border-[#2d2d2d]" />
                  <h3 className="text-4xl font-black tracking-tight mb-2 uppercase">{exp.position}</h3>
                  <div className="flex items-center gap-4 mb-4">
                    <span className="bg-[#4ecdc4] text-white px-3 py-1 text-sm font-bold skew-x-[-12deg]">{exp.company}</span>
                    <span className="text-sm font-bold opacity-30 italic">{exp.startDate} / {exp.current ? 'Present' : exp.endDate}</span>
                  </div>
                  <p className="text-lg opacity-80 leading-relaxed font-sans">{exp.description}</p>
                </div>
              ))}
            </div>
          </section>

          <section>
             <h2 className="text-3xl font-black uppercase mb-10 inline-block bg-[#4ecdc4] text-white px-6 py-2 shadow-[8px_8px_0px_#2d2d2d]">Portfolios</h2>
             <div className="grid grid-cols-2 gap-10">
                {projects.map(project => (
                  <div key={project.id} className="border-4 border-[#2d2d2d] p-8 bg-white hover:bg-[#fdfaf5] transition-colors relative group overflow-hidden">
                    <div className="absolute -right-4 -bottom-4 w-12 h-12 bg-[#ffe66d] border-4 border-[#2d2d2d] rotate-12 transition-transform group-hover:scale-125" />
                    <h3 className="text-3xl font-black mb-4 uppercase">{project.title}</h3>
                    <p className="font-sans mb-6 opacity-80 line-clamp-3">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-8 uppercase text-[10px] font-black">
                       {project.technologies.slice(0, 3).map(tech => (
                         <span key={tech} className="bg-[#2d2d2d] text-white px-2 py-0.5">{tech}</span>
                       ))}
                    </div>
                    <a href={project.link} className="inline-block border-2 border-[#2d2d2d] px-4 py-1 font-black transform transition hover:-translate-y-1 hover:translate-x-1 active:scale-95 bg-white">EXPLORE</a>
                  </div>
                ))}
             </div>
          </section>

          <div className="grid grid-cols-2 gap-16">
            <section>
              <h2 className="text-2xl font-black mb-8 border-b-4 border-[#2d2d2d] pb-2 uppercase tracking-widest">Mastery</h2>
              <div className="space-y-6">
                {skills.map(skill => (
                  <div key={skill.id} className="group">
                    <div className="flex justify-between items-end mb-2">
                       <span className="text-lg font-black uppercase tracking-tighter">{skill.name}</span>
                       <span className="text-xs font-bold opacity-30 italic">Vol: {skill.level}</span>
                    </div>
                    <div className="h-4 border-2 border-[#2d2d2d] p-0.5 bg-white">
                       <div className="h-full bg-[#ff6b6b] transition-all duration-1000" style={{ width: `${skill.level}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-black mb-8 border-b-4 border-[#2d2d2d] pb-2 uppercase tracking-widest">Presence</h2>
              <div className="grid grid-cols-1 gap-4">
                 {socialLinks.map(social => (
                   <a key={social.id} href={social.url} className="text-2xl font-black uppercase tracking-tighter hover:text-[#ff6b6b] transition-colors border-2 border-transparent hover:border-[#2d2d2d] px-4 py-2 flex items-center justify-between group">
                      {social.platform}
                      <span className="opacity-0 group-hover:opacity-100 italic tracking-widest text-xs">→ Link</span>
                   </a>
                 ))}
              </div>
            </section>
          </div>
        </main>

        <footer className="mt-20 pt-10 border-t-8 border-[#2d2d2d] text-center italic text-slate-400 text-sm">
           Generated with SAMA PORTFOLIO BUILDER &copy; 2026
        </footer>
      </div>
    </div>
  );
};
