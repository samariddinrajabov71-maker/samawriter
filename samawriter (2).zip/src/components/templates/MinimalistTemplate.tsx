import React from 'react';
import { PortfolioData } from '../../types';

export const MinimalistTemplate: React.FC<{ data: PortfolioData }> = ({ data }) => {
  const { personalInfo: info, experiences, projects, skills, socialLinks } = data;

  return (
    <div className="p-12 text-gray-800 font-sans leading-relaxed">
      <header className="mb-12 border-b pb-8">
        <h1 className="text-4xl font-light tracking-tight text-gray-900 mb-2">{info.fullName || 'Your Name'}</h1>
        <p className="text-lg text-gray-500 font-medium uppercase tracking-widest text-sm mb-6">{info.title || 'Professional Title'}</p>
        <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-gray-400">
          {info.email && <span>{info.email}</span>}
          {info.phone && <span>{info.phone}</span>}
          {info.location && <span>{info.location}</span>}
        </div>
      </header>

      {info.about && (
        <section className="mb-12">
          <p className="text-gray-600 whitespace-pre-wrap">{info.about}</p>
        </section>
      )}

      {experiences.length > 0 && (
        <section className="mb-12">
          <h2 className="text-xs font-bold text-gray-300 uppercase tracking-[0.2em] mb-6">Experience</h2>
          <div className="space-y-8">
            {experiences.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-baseline mb-1">
                  <h3 className="font-bold text-gray-900">{exp.position}</h3>
                  <span className="text-xs text-gray-400 font-mono">
                    {exp.startDate} — {exp.current ? 'Present' : exp.endDate}
                  </span>
                </div>
                <p className="text-sm font-medium text-gray-500 mb-2">{exp.company}</p>
                <p className="text-sm text-gray-600 whitespace-pre-wrap">{exp.description}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {projects.length > 0 && (
        <section className="mb-12">
          <h2 className="text-xs font-bold text-gray-300 uppercase tracking-[0.2em] mb-6">Selected Projects</h2>
          <div className="grid grid-cols-1 gap-8">
            {projects.map((project) => (
              <div key={project.id}>
                <h3 className="font-bold text-gray-900 mb-1 leading-none">{project.title}</h3>
                <p className="text-xs text-gray-400 mb-3">{project.link}</p>
                <p className="text-sm text-gray-600 mb-3">{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech) => (
                    <span key={tech} className="text-[10px] px-2 py-0.5 bg-gray-50 text-gray-400 rounded-sm border border-gray-100">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <div className="grid grid-cols-2 gap-12">
        {skills.length > 0 && (
          <section>
            <h2 className="text-xs font-bold text-gray-300 uppercase tracking-[0.2em] mb-6">Skills</h2>
            <div className="flex flex-wrap gap-x-4 gap-y-2">
              {skills.map((skill) => (
                <div key={skill.id} className="flex flex-col">
                  <span className="text-sm text-gray-600">{skill.name}</span>
                  <div className="w-24 h-[1px] bg-gray-100 mt-1 relative overflow-hidden">
                    <div className="absolute top-0 left-0 bottom-0 bg-gray-400 transition-all" style={{ width: `${skill.level}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {socialLinks.length > 0 && (
          <section>
            <h2 className="text-xs font-bold text-gray-300 uppercase tracking-[0.2em] mb-6">Connect</h2>
            <div className="flex flex-col gap-2">
              {socialLinks.map((link) => (
                <a key={link.id} href={link.url} className="text-sm text-gray-400 hover:text-gray-900 transition-colors underline-offset-4 hover:underline">
                  {link.platform}
                </a>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};
