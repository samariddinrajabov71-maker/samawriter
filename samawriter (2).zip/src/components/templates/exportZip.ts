import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { PortfolioData } from '../../types';

export const exportToZip = async (data: PortfolioData) => {
  const zip = new JSZip();

  const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${data.personalInfo.fullName} - Portfolio</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-gray-50 text-gray-900 font-sans">
    <div class="max-w-4xl mx-auto py-12 px-6">
        <header class="mb-12">
            <h1 class="text-4xl font-bold mb-2">${data.personalInfo.fullName}</h1>
            <p class="text-xl text-indigo-600 font-medium">${data.personalInfo.title}</p>
            <div class="mt-4 flex flex-wrap gap-4 text-sm text-gray-500">
                <span>${data.personalInfo.email}</span>
                <span>${data.personalInfo.phone}</span>
                <span>${data.personalInfo.location}</span>
            </div>
        </header>

        <section class="mb-12">
            <h2 class="text-2xl font-bold mb-4 border-b pb-2">About</h2>
            <p class="leading-relaxed whitespace-pre-wrap">${data.personalInfo.about}</p>
        </section>

        <section class="mb-12">
            <h2 class="text-2xl font-bold mb-4 border-b pb-2">Experience</h2>
            <div class="space-y-8">
                ${data.experiences.map(exp => `
                    <div>
                        <div class="flex justify-between items-start">
                            <h3 class="font-bold text-lg">${exp.position}</h3>
                            <span class="text-sm text-gray-500">${exp.startDate} - ${exp.current ? 'Present' : exp.endDate}</span>
                        </div>
                        <p class="text-indigo-600 font-medium mb-2">${exp.company}</p>
                        <p class="text-gray-600 whitespace-pre-wrap">${exp.description}</p>
                    </div>
                `).join('')}
            </div>
        </section>

        <section class="mb-12">
            <h2 class="text-2xl font-bold mb-4 border-b pb-2">Projects</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                ${data.projects.map(project => `
                    <div class="border rounded-xl p-6 bg-white shadow-sm">
                        <h3 class="font-bold text-lg mb-2">${project.title}</h3>
                        <p class="text-sm text-gray-600 mb-4">${project.description}</p>
                        <div class="flex flex-wrap gap-2 mb-4">
                            ${project.technologies.map(tech => `
                                <span class="px-2 py-1 bg-indigo-50 text-indigo-600 text-[10px] uppercase font-bold rounded">${tech}</span>
                            `).join('')}
                        </div>
                        <a href="${project.link}" class="text-indigo-600 text-sm font-medium hover:underline">View Project</a>
                    </div>
                `).join('')}
            </div>
        </section>

        <section class="mb-12">
            <h2 class="text-2xl font-bold mb-4 border-b pb-2">Skills</h2>
            <div class="flex flex-wrap gap-3">
                ${data.skills.map(skill => `
                    <div class="bg-gray-100 px-4 py-2 rounded-full flex flex-col items-center">
                        <span class="font-medium text-sm">${skill.name}</span>
                        <div class="w-20 h-1 bg-gray-200 rounded-full mt-1 overflow-hidden">
                            <div class="bg-indigo-600 h-full" style="width: ${skill.level}%"></div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </section>

        <footer>
            <div class="flex justify-center gap-6 text-gray-500 border-t pt-8">
                ${data.socialLinks.map(social => `
                    <a href="${social.url}" class="hover:text-indigo-600 font-medium">${social.platform}</a>
                `).join('')}
            </div>
        </footer>
    </div>
</body>
</html>
  `;

  const cssContent = `
/* Custom Portfolio Styles */
body {
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

@media print {
    .max-w-4xl {
        max-width: 100%;
        padding: 0;
    }
}
  `;

  zip.file('index.html', htmlContent);
  zip.file('style.css', cssContent);

  const content = await zip.generateAsync({ type: 'blob' });
  saveAs(content, 'portfolio-source.zip');
};
