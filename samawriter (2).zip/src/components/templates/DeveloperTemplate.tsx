import React from 'react';
import { PortfolioData } from '../../types';

export const DeveloperTemplate: React.FC<{ data: PortfolioData }> = ({ data }) => {
  const { personalInfo: info, experiences, projects, skills, socialLinks } = data;

  return (
    <div className="min-h-full bg-slate-900 text-slate-300 font-mono p-12">
      <header className="mb-16 border-l-4 border-emerald-500 pl-8 py-2">
        <h1 className="text-5xl font-bold text-white mb-2 leading-tight">
          {info.fullName || 'root@user'}
          <span className="text-emerald-500 animate-pulse">_</span>
        </h1>
        <p className="text-xl text-emerald-400 opacity-80 mb-6">{info.title || 'Full Stack Engineer'}</p>
        <div className="flex flex-wrap gap-4 text-xs text-slate-500">
          {info.email && <span>email: "{info.email}"</span>}
          {info.location && <span>loc: "{info.location}"</span>}
        </div>
      </header>

      <section className="mb-12">
        <h2 className="text-emerald-500 text-xs uppercase mb-4 font-bold flex items-center gap-2">
          <span>{'>'}</span> PROFILE
        </h2>
        <div className="p-6 bg-slate-800/50 rounded-lg border border-slate-700/50 leading-relaxed text-sm">
          {info.about}
        </div>
      </section>

      <div className="grid grid-cols-3 gap-12">
        <div className="col-span-2 space-y-12">
          <section>
            <h2 className="text-emerald-500 text-xs uppercase mb-6 font-bold flex items-center gap-2">
              <span>{'>'}</span> EXPERIENCE
            </h2>
            <div className="space-y-10 border-l border-slate-700 pl-8 ml-2">
              {experiences.map((exp) => (
                <div key={exp.id} className="relative">
                  <div className="absolute -left-[37px] top-1.5 w-4 h-4 bg-slate-900 border-2 border-emerald-500 rounded-full" />
                  <div className="flex justify-between items-baseline mb-2">
                    <h3 className="text-lg font-bold text-white">{exp.position}</h3>
                    <span className="text-xs opacity-40">{exp.startDate} - {exp.current ? 'Present' : exp.endDate}</span>
                  </div>
                  <p className="text-sm text-emerald-400/80 mb-3 italic">{exp.company}</p>
                  <p className="text-xs leading-loose opacity-70 border-l border-slate-800 pl-4">{exp.description}</p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-emerald-500 text-xs uppercase mb-6 font-bold flex items-center gap-2">
              <span>{'>'}</span> PROJECTS
            </h2>
            <div className="grid grid-cols-1 gap-6">
              {projects.map((project) => (
                <div key={project.id} className="p-6 bg-slate-800/30 border border-slate-700 rounded-xl hover:bg-slate-800/50 transition-all group">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="font-bold text-white group-hover:text-emerald-400 transition-colors uppercase tracking-wider">{project.title}</h3>
                    <a href={project.link} className="text-[10px] text-slate-500 hover:text-emerald-500 underline uppercase tracking-widest">Live Link</a>
                  </div>
                  <p className="text-xs opacity-60 mb-4 leading-relaxed">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                      <span key={tech} className="text-[9px] px-2 py-1 bg-slate-900/50 text-slate-400 rounded border border-slate-700 font-mono">
                        #{tech}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        <div className="space-y-12">
          <section>
            <h2 className="text-emerald-500 text-xs uppercase mb-6 font-bold flex items-center gap-2">
              <span>{'>'}</span> TECH_STACK
            </h2>
            <div className="space-y-4">
              {skills.map((skill) => (
                <div key={skill.id} className="space-y-1.5">
                  <div className="flex justify-between text-[10px]">
                    <span className="text-slate-300">{skill.name}</span>
                    <span className="text-emerald-500/50">{skill.level}%</span>
                  </div>
                  <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-emerald-500/60 shadow-[0_0_8px_rgba(16,185,129,0.3)]" 
                      style={{ width: `${skill.level}%` }} 
                    />
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="text-emerald-500 text-xs uppercase mb-6 font-bold flex items-center gap-2">
              <span>{'>'}</span> EXTERNAL_LIBS
            </h2>
            <div className="flex flex-col gap-3">
              {socialLinks.map((link) => (
                <a key={link.id} href={link.url} className="text-xs text-slate-500 hover:text-white transition-colors flex items-center gap-2">
                   <span className="text-[8px] opacity-30">●</span> {link.platform}
                </a>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
