import React, { useEffect, useRef, useState } from 'react';
import { useStore } from '../../store/useStore';
import { MinimalistTemplate } from '../templates/MinimalistTemplate';
import { DeveloperTemplate } from '../templates/DeveloperTemplate';
import { CreativeTemplate } from '../templates/CreativeTemplate';

export const Preview: React.FC = () => {
  const { data } = useStore();
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const containerWidth = containerRef.current.offsetWidth - 48; // Padding
        const resumeWidth = 794; // 210mm at 96 DPI
        if (window.innerWidth < 1024) {
          setScale(containerWidth / resumeWidth);
        } else {
          // On desktop, we can be more generous or stay closer to full scale
          setScale(Math.min(1, containerWidth / resumeWidth));
        }
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const renderTemplate = () => {
    switch (data.theme) {
      case 'developer':
        return <DeveloperTemplate data={data} />;
      case 'creative':
        return <CreativeTemplate data={data} />;
      case 'minimalist':
      default:
        return <MinimalistTemplate data={data} />;
    }
  };

  return (
    <div ref={containerRef} className="h-full overflow-y-auto flex flex-col items-center custom-scroll p-6 lg:p-12">
      <div 
        id="portfolio-preview"
        style={{ transform: `scale(${scale})` }}
        className="w-[210mm] min-h-[297mm] bg-white resume-shadow origin-top transition-transform duration-500 mb-12 shrink-0 overflow-hidden"
      >
        {renderTemplate()}
      </div>
    </div>
  );
};
