import React from 'react';
import { useStore } from '../../store/useStore';
import { ThemeType } from '../../types';
import { cn } from '../../lib/utils';
import { Monitor, Moon, Zap } from 'lucide-react';

export const ThemeSwitcher: React.FC = () => {
  const { data, setTheme } = useStore();

  const themes: { id: ThemeType; label: string; icon: React.ReactNode }[] = [
    { id: 'minimalist', label: 'Minimalist', icon: <Monitor className="w-4 h-4" /> },
    { id: 'developer', label: 'Developer', icon: <Moon className="w-4 h-4" /> },
    { id: 'creative', label: 'Creative', icon: <Zap className="w-4 h-4" /> },
  ];

  return (
    <div className="grid grid-cols-3 gap-3">
      {themes.map((theme) => (
        <button
          key={theme.id}
          onClick={() => setTheme(theme.id)}
          className={cn(
            'flex flex-col items-center justify-center p-3 rounded-lg border transition-all',
            data.theme === theme.id
              ? 'border-black bg-stone-50 text-black shadow-sm'
              : 'border-stone-100 bg-white text-stone-400 hover:border-stone-300 hover:text-black'
          )}
        >
          {theme.icon}
          <span className="text-[9px] font-black uppercase tracking-wider mt-1.5">{theme.label}</span>
        </button>
      ))}
    </div>
  );
};
