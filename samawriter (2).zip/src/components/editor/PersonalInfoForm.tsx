import React from 'react';
import { useStore } from '../../store/useStore';
import { dictionaries } from '../../i18n/dictionaries';

export const PersonalInfoForm: React.FC = () => {
  const { language, data, updatePersonalInfo } = useStore();
  const dict = dictionaries[language];
  const info = data.personalInfo;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    updatePersonalInfo({ [name]: value });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-6">
      <div className="md:col-span-2">
        <label className="text-[10px] font-bold uppercase text-stone-500 block mb-1.5 tracking-wider">{dict.fields.fullName}</label>
        <input
          type="text"
          name="fullName"
          value={info.fullName}
          onChange={handleChange}
          className="w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-black placeholder:text-stone-300 transition-all"
        />
      </div>
      <div>
        <label className="text-[10px] font-bold uppercase text-stone-500 block mb-1.5 tracking-wider">{dict.fields.title}</label>
        <input
          type="text"
          name="title"
          value={info.title}
          onChange={handleChange}
          className="w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-black placeholder:text-stone-300 transition-all"
        />
      </div>
      <div>
        <label className="text-[10px] font-bold uppercase text-stone-500 block mb-1.5 tracking-wider">{dict.fields.email}</label>
        <input
          type="email"
          name="email"
          value={info.email}
          onChange={handleChange}
          className="w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-black placeholder:text-stone-300 transition-all"
        />
      </div>
      <div>
        <label className="text-[10px] font-bold uppercase text-stone-500 block mb-1.5 tracking-wider">{dict.fields.phone}</label>
        <input
          type="text"
          name="phone"
          value={info.phone}
          onChange={handleChange}
          className="w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-black placeholder:text-stone-300 transition-all"
        />
      </div>
      <div>
        <label className="text-[10px] font-bold uppercase text-stone-500 block mb-1.5 tracking-wider">{dict.fields.location}</label>
        <input
          type="text"
          name="location"
          value={info.location}
          onChange={handleChange}
          className="w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-black placeholder:text-stone-300 transition-all"
        />
      </div>
      <div className="col-span-2">
        <label className="text-[10px] font-bold uppercase text-stone-500 block mb-1.5 tracking-wider">{dict.fields.about}</label>
        <textarea
          name="about"
          value={info.about}
          onChange={handleChange}
          rows={4}
          className="w-full border border-stone-200 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-black placeholder:text-stone-300 transition-all resize-none"
        />
      </div>
    </div>
  );
};
