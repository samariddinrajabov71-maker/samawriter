import React from 'react';
import { useStore } from '../../store/useStore';
import { dictionaries } from '../../i18n/dictionaries';
import { Crown, CreditCard, Phone, CheckCircle2, X } from 'lucide-react';

interface ProModalProps {
  onClose: () => void;
}

export const ProModal: React.FC<ProModalProps> = ({ onClose }) => {
  const { language } = useStore();
  const dict = dictionaries[language];

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-md" onClick={onClose} />
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md p-8 animate-in fade-in zoom-in duration-300 overflow-hidden">
        {/* Gradient Header */}
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-200" />
        
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 text-stone-400 hover:text-stone-900 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex flex-col items-center text-center space-y-8">
          <div className="relative">
            <div className="w-20 h-20 bg-amber-50 rounded-full flex items-center justify-center">
              <Crown className="w-10 h-10 text-amber-500" />
            </div>
            <div className="absolute -bottom-2 -right-2 bg-black text-white text-[10px] font-black px-2 py-1 rounded-lg uppercase tracking-tighter shadow-lg">
              {dict.app.pro.price}
            </div>
          </div>

          <div className="space-y-3">
            <h2 className="text-2xl font-black uppercase tracking-tight text-stone-900 leading-none">
              {dict.app.pro.title}
            </h2>
            <p className="text-xs text-stone-500 font-medium leading-relaxed">
              {dict.app.pro.limitMessage}
            </p>
          </div>

          <div className="w-full space-y-4">
            {/* Payment Card */}
            <div className="p-6 bg-stone-50 rounded-2xl border border-stone-100 text-left space-y-4">
              <div className="space-y-1">
                <p className="text-[10px] font-black uppercase tracking-widest text-stone-400">
                  {dict.app.pro.instructions}
                </p>
                <div className="flex items-center gap-3">
                  <CreditCard className="w-5 h-5 text-indigo-600" />
                  <p className="text-lg font-mono font-bold text-stone-900 tracking-wider">
                    {dict.app.pro.cardNumber}
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-stone-200 space-y-1">
                <p className="text-[10px] font-black uppercase tracking-widest text-stone-400">
                  {dict.app.pro.contact}
                </p>
                <div className="flex items-center gap-3 text-indigo-600">
                  <Phone className="w-4 h-4" />
                  <a href={`tel:${dict.app.pro.phoneNumber.replace(/\s/g, '')}`} className="text-sm font-black tracking-tight hover:underline">
                    {dict.app.pro.phoneNumber}
                  </a>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-[10px] font-bold text-emerald-600 uppercase tracking-widest justify-center">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Unlimited PDF Exports
              </div>
              <div className="flex items-center gap-2 text-[10px] font-bold text-emerald-600 uppercase tracking-widest justify-center">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Unlimited Zip Downloads
              </div>
            </div>
          </div>

          <button
            onClick={() => window.open(`tel:${dict.app.pro.phoneNumber.replace(/\s/g, '')}`)}
            className="w-full py-5 bg-black text-white hover:bg-stone-800 rounded-2xl text-xs font-black uppercase tracking-[0.2em] transition-all shadow-xl shadow-stone-200"
          >
            {dict.app.pro.upgradeBtn}
          </button>
        </div>
      </div>
    </div>
  );
};
