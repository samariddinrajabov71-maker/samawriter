import React from 'react';
import { useStore } from '../../store/useStore';
import { dictionaries } from '../../i18n/dictionaries';
import { Plus, Trash2, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ListFormProps {
  type: 'experiences' | 'projects' | 'skills' | 'socialLinks';
}

export const ListForm: React.FC<ListFormProps> = ({ type }) => {
  const { language, data, updateData } = useStore();
  const dict = dictionaries[language];
  const items = data[type] as any[];

  const addItem = () => {
    let newItem: any = { id: Math.random().toString(36).substr(2, 9) };
    if (type === 'experiences') newItem = { ...newItem, company: '', position: '', startDate: '', endDate: '', current: false, description: '' };
    if (type === 'projects') newItem = { ...newItem, title: '', description: '', link: '', technologies: [] };
    if (type === 'skills') newItem = { ...newItem, name: '', level: 80 };
    if (type === 'socialLinks') newItem = { ...newItem, platform: '', url: '' };

    updateData({ [type]: [...items, newItem] });
  };

  const removeItem = (id: string) => {
    updateData({ [type]: items.filter((item) => item.id !== id) });
  };

  const updateItem = (id: string, updates: any) => {
    updateData({
      [type]: items.map((item) => (item.id === id ? { ...item, ...updates } : item)),
    });
  };

  return (
    <div className="space-y-4">
      <AnimatePresence>
        {items.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="p-5 bg-stone-50 rounded-xl border border-stone-100 relative group"
          >
            <button
              onClick={() => removeItem(item.id)}
              className="absolute top-3 right-3 p-1.5 text-stone-300 hover:text-red-500 hover:bg-white rounded-md opacity-0 group-hover:opacity-100 transition-all border border-transparent hover:border-red-100"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>

            {type === 'experiences' && (
              <div className="grid grid-cols-2 gap-4 pt-2">
                <input
                  placeholder={dict.fields.company}
                  value={item.company}
                  onChange={(e) => updateItem(item.id, { company: e.target.value })}
                  className="px-3 py-2 bg-white border border-stone-200 rounded-md text-xs focus:ring-1 focus:ring-black outline-none"
                />
                <input
                  placeholder={dict.fields.position}
                  value={item.position}
                  onChange={(e) => updateItem(item.id, { position: e.target.value })}
                  className="px-3 py-2 bg-white border border-stone-200 rounded-md text-xs focus:ring-1 focus:ring-black outline-none"
                />
                <input
                  type="date"
                  value={item.startDate}
                  onChange={(e) => updateItem(item.id, { startDate: e.target.value })}
                  className="px-3 py-2 bg-white border border-stone-200 rounded-md text-xs focus:ring-1 focus:ring-black outline-none"
                />
                <input
                  type="date"
                  value={item.endDate}
                  disabled={item.current}
                  onChange={(e) => updateItem(item.id, { endDate: e.target.value })}
                  className="px-3 py-2 bg-white border border-stone-200 rounded-md text-xs focus:ring-1 focus:ring-black outline-none disabled:opacity-30"
                />
                <div className="col-span-2 flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={item.current}
                    onChange={(e) => updateItem(item.id, { current: e.target.checked })}
                    id={`current-${item.id}`}
                    className="accent-black"
                  />
                  <label htmlFor={`current-${item.id}`} className="text-[10px] font-bold text-stone-500 uppercase tracking-tighter">
                    {dict.fields.current}
                  </label>
                </div>
                <textarea
                  placeholder={dict.fields.description}
                  value={item.description}
                  onChange={(e) => updateItem(item.id, { description: e.target.value })}
                  className="col-span-2 px-3 py-2 bg-white border border-stone-200 rounded-md text-xs h-20 focus:ring-1 focus:ring-black outline-none resize-none"
                />
              </div>
            )}

            {type === 'projects' && (
              <div className="grid grid-cols-1 gap-4 pt-2">
                <input
                  placeholder={dict.fields.projectTitle}
                  value={item.title}
                  onChange={(e) => updateItem(item.id, { title: e.target.value })}
                   className="px-3 py-2 bg-white border border-stone-200 rounded-md text-xs focus:ring-1 focus:ring-black outline-none"
                />
                <input
                  placeholder={dict.fields.projectLink}
                  value={item.link}
                  onChange={(e) => updateItem(item.id, { link: e.target.value })}
                   className="px-3 py-2 bg-white border border-stone-200 rounded-md text-xs focus:ring-1 focus:ring-black outline-none"
                />
                <input
                  placeholder={dict.fields.technologies}
                  value={item.technologies.join(', ')}
                  onChange={(e) => updateItem(item.id, { technologies: e.target.value.split(',').map((t: string) => t.trim()) })}
                   className="px-3 py-2 bg-white border border-stone-200 rounded-md text-xs focus:ring-1 focus:ring-black outline-none"
                />
                <textarea
                  placeholder={dict.fields.description}
                  value={item.description}
                  onChange={(e) => updateItem(item.id, { description: e.target.value })}
                   className="px-3 py-2 bg-white border border-stone-200 rounded-md text-xs h-20 focus:ring-1 focus:ring-black outline-none resize-none"
                />
              </div>
            )}

            {type === 'skills' && (
              <div className="flex items-center gap-4 pt-2">
                <input
                  placeholder={dict.fields.skillName}
                  value={item.name}
                  onChange={(e) => updateItem(item.id, { name: e.target.value })}
                  className="flex-1 px-3 py-2 bg-white border border-stone-200 rounded-md text-xs focus:ring-1 focus:ring-black outline-none"
                />
                <div className="flex items-center gap-3 w-1/3">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={item.level}
                    onChange={(e) => updateItem(item.id, { level: parseInt(e.target.value) })}
                    className="flex-1 accent-black"
                  />
                  <span className="text-[10px] font-black font-mono text-stone-400 w-8">{item.level}%</span>
                </div>
              </div>
            )}

            {type === 'socialLinks' && (
              <div className="grid grid-cols-2 gap-4 pt-2">
                <input
                  placeholder={dict.fields.platform}
                  value={item.platform}
                  onChange={(e) => updateItem(item.id, { platform: e.target.value })}
                  className="px-3 py-2 bg-white border border-stone-200 rounded-md text-xs focus:ring-1 focus:ring-black outline-none"
                />
                <input
                  placeholder={dict.fields.url}
                  value={item.url}
                  onChange={(e) => updateItem(item.id, { url: e.target.value })}
                  className="px-3 py-2 bg-white border border-stone-200 rounded-md text-xs focus:ring-1 focus:ring-black outline-none"
                />
              </div>
            )}
          </motion.div>
        ))}
      </AnimatePresence>

      <button
        onClick={addItem}
        className="w-full py-2.5 border border-stone-200 border-dashed rounded-lg text-stone-400 hover:text-black hover:bg-stone-50 transition-all flex items-center justify-center gap-2 font-bold text-[10px] uppercase tracking-widest"
      >
        <Plus className="w-3 h-3" />
        {dict.actions.add}
      </button>
    </div>
  );
};
