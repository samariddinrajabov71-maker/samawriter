import React from 'react';
import { TabType, useStore } from '../../store/useStore';
import { dictionaries } from '../../i18n/dictionaries';
import { User, Briefcase, Code, Star, Share2, Palette } from 'lucide-react';
import { PersonalInfoForm } from './PersonalInfoForm';
import { ListForm } from './ListForm';
import { ThemeSwitcher } from './ThemeSwitcher';
import { TemplatesTab } from './TemplatesTab';
import { SettingsTab } from './SettingsTab';
import { ProfileTab } from './ProfileTab';
import { cn } from '../../lib/utils';
import { motion } from 'motion/react';

export const Editor: React.FC = () => {
  const { language, activeTab, setActiveTab } = useStore();
  const dict = dictionaries[language];

  const tabs: { id: TabType; label: string }[] = [
    { id: 'content', label: dict.app.tabs.content },
    { id: 'templates', label: dict.app.tabs.templates },
    { id: 'settings', label: dict.app.tabs.settings },
    { id: 'profile', label: dict.app.tabs.profile },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'templates':
        return <TemplatesTab />;
      case 'settings':
        return <SettingsTab />;
      case 'profile':
        return <ProfileTab />;
      case 'content':
      default:
        return (
          <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <Section title={dict.sections.personalInfo} icon={<User className="w-4 h-4 text-stone-400 group-hover:text-black transition-colors" />}>
              <PersonalInfoForm />
            </Section>

            <Section title={dict.sections.experience} icon={<Briefcase className="w-4 h-4 text-stone-400 group-hover:text-black transition-colors" />}>
              <ListForm type="experiences" />
            </Section>

            <Section title={dict.sections.skills} icon={<Star className="w-4 h-4 text-stone-400 group-hover:text-black transition-colors" />}>
              <ListForm type="skills" />
            </Section>

            <Section title={dict.sections.projects} icon={<Code className="w-4 h-4 text-stone-400 group-hover:text-black transition-colors" />}>
              <ListForm type="projects" />
            </Section>

            <Section title={dict.sections.socialLinks} icon={<Share2 className="w-4 h-4 text-stone-400 group-hover:text-black transition-colors" />}>
              <ListForm type="socialLinks" />
            </Section>
          </div>
        );
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-white relative">
      <nav className="flex border-b border-stone-100 shrink-0 overflow-x-auto no-scrollbar scroll-smooth bg-white/80 backdrop-blur-md sticky top-0 z-10">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              "flex-1 min-w-[80px] py-4 text-[10px] font-black tracking-widest uppercase transition-all relative",
              activeTab === tab.id ? "text-black" : "text-stone-300 hover:text-stone-500"
            )}
          >
            <span className="relative z-10">{tab.label}</span>
            {activeTab === tab.id && (
              <motion.div 
                layoutId="active-tab"
                className="absolute bottom-0 left-4 right-4 h-0.5 bg-black" 
                transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
              />
            )}
          </button>
        ))}
      </nav>

      <div className="flex-1 overflow-y-auto custom-scroll p-6 lg:p-8">
        {renderContent()}
      </div>
      
      <footer className="p-4 border-t border-stone-100 bg-stone-50/20 flex justify-between items-center shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
          <span className="text-[9px] text-stone-400 font-bold uppercase tracking-tighter">Live Sync Active</span>
        </div>
        <span className="text-[8px] text-stone-300 font-medium uppercase tracking-widest">SaMaWriter v2.1</span>
      </footer>
    </div>
  );
};

interface SectionProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

const Section: React.FC<SectionProps> = ({ title, icon, children }) => (
  <div className="space-y-4 group">
    <div className="flex items-center gap-2 border-b border-stone-100 pb-2">
      {icon}
      <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-400 group-hover:text-stone-900 transition-colors">
        {title}
      </h3>
    </div>
    <div className="pt-1">
      {children}
    </div>
  </div>
);
