import React from 'react';
import { useStore } from '../../store/useStore';
import { dictionaries } from '../../i18n/dictionaries';
import { ThemeSwitcher } from './ThemeSwitcher';
import { Palette, Box } from 'lucide-react';

export const TemplatesTab: React.FC = () => {
  const { language } = useStore();
  const dict = dictionaries[language];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="space-y-4">
        <div className="flex items-center gap-2 border-b border-stone-100 pb-2">
          <Palette className="w-4 h-4 text-stone-400" />
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-900">
            {dict.sections.theme}
          </h3>
        </div>
        <ThemeSwitcher />
      </div>

      <div className="p-8 border border-stone-100 rounded-2xl bg-stone-50/50 flex flex-col items-center justify-center text-center space-y-4">
        <Box className="w-12 h-12 text-stone-200" />
        <div className="space-y-1">
          <p className="text-xs font-bold text-stone-900">More Templates Coming Soon</p>
          <p className="text-[10px] text-stone-400 font-medium">We are working on high-performance custom layouts.</p>
        </div>
      </div>
    </div>
  );
};
