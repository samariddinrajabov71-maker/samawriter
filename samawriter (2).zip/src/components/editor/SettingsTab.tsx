import React from 'react';
import { useStore } from '../../store/useStore';
import { dictionaries } from '../../i18n/dictionaries';
import { Trash2, Download, Upload, ShieldAlert, Database } from 'lucide-react';

export const SettingsTab: React.FC = () => {
  const { language, data, updateData } = useStore();
  const dict = dictionaries[language];

  const handleReset = () => {
    if (window.confirm(dict.settings.resetConfirm)) {
      updateData({
        personalInfo: { fullName: '', title: '', email: '', phone: '', location: '', about: '' },
        experiences: [],
        projects: [],
        skills: [],
        socialLinks: [],
        theme: 'minimalist',
      });
    }
  };

  const handleExportJson = () => {
    const backup = JSON.stringify(data, null, 2);
    const blob = new Blob([backup], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `portfolio-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const importedData = JSON.parse(event.target?.result as string);
        updateData(importedData);
      } catch (err) {
        alert('Invalid JSON file');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Data Management */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 border-b border-stone-100 pb-2">
          <Database className="w-4 h-4 text-stone-400" />
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-900">
            {dict.sections.dataManagement}
          </h3>
        </div>
        
        <div className="grid grid-cols-1 gap-3">
          <button
            onClick={handleExportJson}
            className="flex items-center justify-between p-4 bg-white border border-stone-100 rounded-xl hover:border-stone-200 transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-stone-50 rounded-lg flex items-center justify-center group-hover:bg-indigo-50 transition-colors">
                <Download className="w-4 h-4 text-stone-400 group-hover:text-indigo-600" />
              </div>
              <span className="text-xs font-bold text-stone-700">{dict.settings.exportJson}</span>
            </div>
          </button>

          <label className="flex items-center justify-between p-4 bg-white border border-stone-100 rounded-xl hover:border-stone-200 transition-all group cursor-pointer">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-stone-50 rounded-lg flex items-center justify-center group-hover:bg-indigo-50 transition-colors">
                <Upload className="w-4 h-4 text-stone-400 group-hover:text-indigo-600" />
              </div>
              <span className="text-xs font-bold text-stone-700">{dict.settings.importJson}</span>
            </div>
            <input type="file" accept=".json" onChange={handleImportJson} className="hidden" />
          </label>
        </div>
      </section>

      {/* Danger Zone */}
      <section className="space-y-6">
        <div className="flex items-center gap-2 border-b border-stone-100 pb-2">
          <ShieldAlert className="w-4 h-4 text-red-400" />
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-red-500">
            {dict.sections.dangerZone}
          </h3>
        </div>
        
        <div className="p-4 bg-red-50/50 rounded-2xl border border-red-100 space-y-4">
          <p className="text-[10px] text-red-600 font-medium leading-relaxed">
            Resetting the data will erase everything permanently. Make sure you have exported a backup if you want to keep your data.
          </p>
          <button
            onClick={handleReset}
            className="w-full py-3 bg-white border border-red-200 text-red-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-600 hover:text-white transition-all shadow-sm"
          >
            <Trash2 className="w-4 h-4 inline mr-2" />
            {dict.settings.reset}
          </button>
        </div>
      </section>
    </div>
  );
};
