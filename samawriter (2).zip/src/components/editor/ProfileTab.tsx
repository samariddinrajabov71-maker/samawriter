import React from 'react';
import { useStore } from '../../store/useStore';
import { useAuth } from '../../store/AuthContext';
import { dictionaries } from '../../i18n/dictionaries';
import { 
  User as UserIcon, 
  Cloud, 
  BarChart3, 
  Settings as SettingsIcon, 
  CheckCircle2, 
  AlertCircle,
  FileText,
  Download,
  Share2,
  Crown,
  Instagram,
  Send,
  Smartphone,
  ShieldCheck
} from 'lucide-react';
import { cn } from '../../lib/utils';

export const ProfileTab: React.FC = () => {
  const { language, exportCount, isPro } = useStore();
  const { user } = useAuth();
  const dict = dictionaries[language];

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center p-8 space-y-4">
        <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center text-stone-300">
          <UserIcon className="w-8 h-8" />
        </div>
        <div className="space-y-1">
          <h3 className="text-sm font-bold text-stone-900">{dict.app.auth.loginRequired}</h3>
          <p className="text-xs text-stone-500 font-medium max-w-xs">
            {dict.app.auth.loginRequiredMessage}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* 1. Account Info Part */}
      <section className="space-y-4">
        <div className="flex items-center gap-2 border-b border-stone-100 pb-2">
          <UserIcon className="w-4 h-4 text-stone-400" />
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-900">
            {dict.sections.accountInfo}
          </h3>
        </div>
        
        <div className="flex items-center gap-4 p-5 bg-stone-50/50 rounded-2xl border border-stone-100">
          <img 
            src={user.photoURL || ''} 
            alt={user.displayName || ''} 
            className="w-16 h-16 rounded-full border-2 border-white shadow-sm"
          />
          <div className="space-y-1">
            <h4 className="text-sm font-black text-stone-900 uppercase tracking-tight">
              {user.displayName}
            </h4>
            <p className="text-xs text-stone-500 font-medium">{user.email}</p>
            <div className="flex items-center gap-2">
              <div className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-emerald-50 text-emerald-600 rounded-full">
                <CheckCircle2 className="w-3 h-3" />
                <span className="text-[9px] font-black uppercase tracking-wider">Verified Account</span>
              </div>
              {isPro && (
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-amber-50 text-amber-600 rounded-full">
                  <Crown className="w-3 h-3" />
                  <span className="text-[9px] font-black uppercase tracking-wider">PRO</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* 2. Cloud Synchronization Status Part */}
      <section className="space-y-4">
        <div className="flex items-center gap-2 border-b border-stone-100 pb-2">
          <Cloud className="w-4 h-4 text-stone-400" />
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-900">
            {dict.sections.cloudSync}
          </h3>
        </div>

        <div className="grid grid-cols-1 gap-3">
          <div className="p-4 bg-white border border-stone-100 rounded-xl flex items-center justify-between group">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-indigo-50 rounded-lg flex items-center justify-center text-indigo-600">
                <CheckCircle2 className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <p className="text-[10px] font-black uppercase tracking-wider text-stone-900">Auto-Sync Enabled</p>
                <p className="text-[9px] text-stone-400 font-medium uppercase tracking-tighter">Last synced: Just now</p>
              </div>
            </div>
            <button className="text-[8px] font-black uppercase tracking-widest text-indigo-600 hover:underline">
              Sync Now
            </button>
          </div>
          
          <div className="p-4 bg-white border border-stone-100 rounded-xl flex items-center justify-between opacity-50 cursor-not-allowed">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-stone-50 rounded-lg flex items-center justify-center text-stone-400">
                <Download className="w-4 h-4" />
              </div>
              <div className="space-y-0.5">
                <p className="text-[10px] font-black uppercase tracking-wider text-stone-900">History Backups</p>
                <p className="text-[9px] text-stone-400 font-medium uppercase tracking-tighter">Premium Feature</p>
              </div>
            </div>
            <BarChart3 className="w-4 h-4 text-stone-300" />
          </div>
        </div>
      </section>

      {/* 3. Usage Statistics Part */}
      <section className="space-y-4">
        <div className="flex items-center gap-2 border-b border-stone-100 pb-2">
          <BarChart3 className="w-4 h-4 text-stone-400" />
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-900">
            {dict.sections.stats}
          </h3>
        </div>

        <div className="grid grid-cols-3 gap-3">
          <div className="p-4 bg-stone-50 rounded-2xl flex flex-col items-center justify-center text-center space-y-1">
            <FileText className="w-4 h-4 text-stone-400" />
            <p className="text-lg font-black text-stone-900">1</p>
            <p className="text-[8px] font-black uppercase tracking-widest text-stone-400">Project</p>
          </div>
          <div className="p-4 bg-stone-50 rounded-2xl flex flex-col items-center justify-center text-center space-y-1">
            <Download className="w-4 h-4 text-stone-400" />
            <p className="text-lg font-black text-stone-900">{exportCount}</p>
            <p className="text-[8px] font-black uppercase tracking-widest text-stone-400">Exports</p>
          </div>
          <div className="p-4 bg-stone-50 rounded-2xl flex flex-col items-center justify-center text-center space-y-1">
            <BarChart3 className="w-4 h-4 text-stone-400" />
            <p className="text-lg font-black text-stone-900">{isPro ? '∞' : Math.max(0, 3 - exportCount)}</p>
            <p className="text-[8px] font-black uppercase tracking-widest text-stone-400">{isPro ? 'Unlimited' : 'Remaining'}</p>
          </div>
        </div>
      </section>

      {/* 4. App Preferences Summary Part */}
      <section className="space-y-4">
        <div className="flex items-center gap-2 border-b border-stone-100 pb-2">
          <SettingsIcon className="w-4 h-4 text-stone-400" />
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-900">
            System Status
          </h3>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between text-[10px] font-bold">
            <span className="text-stone-400 uppercase tracking-widest">Interface Locale</span>
            <span className="text-stone-900 uppercase">{language}</span>
          </div>
          <div className="flex items-center justify-between text-[10px] font-bold">
            <span className="text-stone-400 uppercase tracking-widest">Storage API</span>
            <span className="text-stone-900 uppercase">Cloud Firestore</span>
          </div>
          <div className="flex items-center justify-between text-[10px] font-bold">
            <span className="text-stone-400 uppercase tracking-widest">Auth Provider</span>
            <span className="text-stone-900 uppercase">Google Identity</span>
          </div>
        </div>
      </section>

      {/* 5. Ownership & Support Part */}
      <section className="space-y-4">
        <div className="flex items-center gap-2 border-b border-stone-100 pb-2">
          <ShieldCheck className="w-4 h-4 text-stone-400" />
          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-stone-900">
            {dict.sections.ownership}
          </h3>
        </div>

        <div className="p-5 bg-indigo-50/30 rounded-2xl border border-indigo-100/50 space-y-4">
          <p className="text-[10px] font-bold text-indigo-900 uppercase tracking-tight leading-relaxed">
            This platform is owned and maintained by Samariddin Rajabov. For any technical support or payment verifications, please reach out via:
          </p>
          
          <div className="grid grid-cols-1 gap-3">
            <a 
              href={`tel:${dict.owner.phone.replace(/\s/g, '')}`}
              className="flex items-center gap-3 p-3 bg-white rounded-xl border border-stone-100 hover:border-indigo-200 transition-colors group"
            >
              <div className="w-8 h-8 bg-stone-50 rounded-lg flex items-center justify-center text-stone-400 group-hover:text-indigo-600">
                <Smartphone className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-stone-600">{dict.owner.phone}</span>
            </a>

            <a 
              href="https://t.me/SamariddinRajabov"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 bg-white rounded-xl border border-stone-100 hover:border-indigo-200 transition-colors group"
            >
              <div className="w-8 h-8 bg-stone-50 rounded-lg flex items-center justify-center text-stone-400 group-hover:text-indigo-600">
                <Send className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-stone-600">{dict.owner.telegram}</span>
            </a>

            <a 
              href="https://instagram.com/samardobriy"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 bg-white rounded-xl border border-stone-100 hover:border-indigo-200 transition-colors group"
            >
              <div className="w-8 h-8 bg-stone-50 rounded-lg flex items-center justify-center text-stone-400 group-hover:text-indigo-600">
                <Instagram className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-stone-600">{dict.owner.instagram}</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
