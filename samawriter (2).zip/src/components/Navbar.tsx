import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { dictionaries } from '../i18n/dictionaries';
import { Language } from '../types';
import { Globe, Download, Code, Palette, LogIn, LogOut, User as UserIcon, X } from 'lucide-react';
import { cn } from '../lib/utils';
import { exportToZip } from './templates/exportZip';
import { downloadPdf } from '../utils/exportPdf';
import { useAuth } from '../store/AuthContext';
import { ProModal } from './editor/ProModal';

export const Navbar: React.FC = () => {
  const { language, setLanguage, data, setActiveTab, exportCount, isPro, incrementExportCount } = useStore();
  const { user, signIn, logout, isSigningIn } = useAuth();
  const dict = dictionaries[language];
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  const [showProModal, setShowProModal] = useState(false);

  const canExport = isPro || exportCount < 3;

  const handleDownloadPdf = () => {
    if (!user) {
      setShowLoginPrompt(true);
      return;
    }
    if (!canExport) {
      setShowProModal(true);
      return;
    }
    downloadPdf('portfolio-preview');
    incrementExportCount();
  };

  const handleExportZip = () => {
    if (!user) {
      setShowLoginPrompt(true);
      return;
    }
    if (!canExport) {
      setShowProModal(true);
      return;
    }
    exportToZip(data);
    incrementExportCount();
  };

  return (
    <>
      <nav className="h-16 bg-white/80 backdrop-blur-xl border-b border-stone-200 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-black rounded-lg flex items-center justify-center text-white">
            <UserIcon className="w-4 h-4" />
          </div>
          <span className="font-bold text-xl tracking-tight uppercase text-stone-900">SaMaWriter</span>
        </div>

        <div className="flex items-center gap-6">
          {/* Language Switcher */}
          <div className="hidden md:flex items-center bg-stone-100 rounded-full px-1 py-1">
            {(['en', 'uz', 'ru'] as Language[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={cn(
                  "px-4 py-1 text-[10px] font-bold rounded-full transition-all uppercase",
                  language === lang 
                    ? "bg-white shadow-sm text-stone-900" 
                    : "text-stone-400 hover:text-stone-600"
                )}
              >
                {lang}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExportZip}
              className="flex items-center gap-2 border border-stone-300 px-3 sm:px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider hover:bg-stone-50 transition-colors"
            >
              <Code className="w-3.5 h-3.5 text-stone-600" />
              <span className="hidden md:inline">{dict.app.exportCode}</span>
            </button>
            
            <button
              onClick={handleDownloadPdf}
              className="flex items-center gap-2 bg-black text-white px-3 sm:px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider hover:bg-stone-800 shadow-lg shadow-stone-200 transition-all"
            >
              <Download className="w-3.5 h-3.5 text-white" />
              <span className="hidden md:inline text-white">{dict.app.downloadPdf}</span>
            </button>

            <div className="h-8 w-[1px] bg-stone-200 mx-1 hidden sm:block" />

            {user ? (
              <div 
                className="flex items-center gap-3 cursor-pointer" 
                onClick={() => setActiveTab('profile')}
              >
                <div className="hidden sm:block text-right">
                  <p className="text-[10px] font-bold text-stone-900 uppercase tracking-tight truncate max-w-[100px]">
                    {user.displayName}
                  </p>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      logout();
                    }} 
                    className="text-[8px] font-bold text-red-500 uppercase tracking-widest hover:text-red-600"
                  >
                    {dict.app.auth.signOut}
                  </button>
                </div>
                <img src={user.photoURL || ''} alt={user.displayName || ''} className="w-8 h-8 rounded-full border border-stone-200 hover:border-black transition-colors" />
              </div>
            ) : (
              <button
                onClick={() => signIn()}
                disabled={isSigningIn}
                className="flex items-center gap-2 px-4 py-2 text-[10px] font-black uppercase tracking-[0.2em] text-stone-900 hover:text-black transition-all disabled:opacity-50"
              >
                <LogIn className="w-4 h-4" />
                <span className="hidden sm:inline">{isSigningIn ? '...' : dict.app.auth.signIn}</span>
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Login Required Prompt Modal */}
      {showLoginPrompt && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-stone-900/40 backdrop-blur-sm" onClick={() => setShowLoginPrompt(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-sm p-8 animate-in fade-in zoom-in duration-200">
            <button 
              onClick={() => setShowLoginPrompt(false)}
              className="absolute top-4 right-4 text-stone-400 hover:text-stone-900 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="flex flex-col items-center text-center space-y-6">
              <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center">
                <LogIn className="w-8 h-8 text-stone-900" />
              </div>
              
              <div className="space-y-2">
                <h2 className="text-lg font-black uppercase tracking-widest text-stone-900">
                  {dict.app.auth.loginRequired}
                </h2>
                <p className="text-xs text-stone-500 font-medium leading-relaxed">
                  {dict.app.auth.loginRequiredMessage}
                </p>
              </div>

              <button
                onClick={() => {
                  signIn();
                  setShowLoginPrompt(false);
                }}
                disabled={isSigningIn}
                className="w-full flex items-center justify-center gap-3 bg-black text-white hover:bg-stone-800 px-6 py-4 rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-xl shadow-stone-200 disabled:opacity-50"
              >
                <LogIn className="w-4 h-4" />
                {isSigningIn ? '...' : dict.app.auth.signIn}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Pro Modal */}
      {showProModal && <ProModal onClose={() => setShowProModal(false)} />}
    </>
  );
};
